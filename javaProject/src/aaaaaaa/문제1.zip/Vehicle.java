package aaaaaaa;

public interface Vehicle {
	public void speedUp();
	public void speedDown();
	public void handle();
}
